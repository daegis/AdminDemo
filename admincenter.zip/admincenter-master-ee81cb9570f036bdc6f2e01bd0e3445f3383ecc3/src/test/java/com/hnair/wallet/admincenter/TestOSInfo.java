package com.hnair.wallet.admincenter;

import org.junit.Test;

/**
 * Using IntelliJ IDEA.
 *
 * @author XIANYINGDA at 7/25/2018 6:09 PM
 */
public class TestOSInfo {

    @Test
    public void test01() {

    }
}
