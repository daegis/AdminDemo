package com.hnair.wallet.admincenter.service.impl;

import cn.aegisa.selext.dao.service.ICommonService;
import com.hnair.wallet.admincenter.service.IConsumeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Using IntelliJ IDEA.
 *
 * @author XIANYINGDA at 7/27/2018 10:28 AM
 */
@Service
@Slf4j
public class ConsumeServiceImpl implements IConsumeService {

    @Autowired
    private ICommonService db;


}
