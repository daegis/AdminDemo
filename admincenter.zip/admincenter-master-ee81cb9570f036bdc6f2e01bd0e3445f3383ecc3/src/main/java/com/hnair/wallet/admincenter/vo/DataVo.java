package com.hnair.wallet.admincenter.vo;

import lombok.Data;

import java.util.List;

/**
 * Using IntelliJ IDEA.
 *
 * @author 李小鑫 at 2018/7/25 10:17
 */
@Data
public class DataVo {

    List<Integer> ids;
}
