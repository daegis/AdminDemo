package com.hnair.wallet.admincenter.vo;

import lombok.Data;

/**
 * Using IntelliJ IDEA.
 *
 * @author XIANYINGDA at 7/24/2018 4:41 PM
 */
@Data
public class RestResponse {
    private Boolean success;
    private String message;
}
