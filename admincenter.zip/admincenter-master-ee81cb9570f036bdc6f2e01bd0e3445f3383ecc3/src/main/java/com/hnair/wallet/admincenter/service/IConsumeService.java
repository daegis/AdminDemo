package com.hnair.wallet.admincenter.service;

/**
 * Using IntelliJ IDEA.
 *
 * @author XIANYINGDA at 7/27/2018 10:28 AM
 */
public interface IConsumeService {
}
