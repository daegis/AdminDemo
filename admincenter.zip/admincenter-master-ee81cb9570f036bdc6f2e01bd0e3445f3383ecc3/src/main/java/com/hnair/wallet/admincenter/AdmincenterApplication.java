package com.hnair.wallet.admincenter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmincenterApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdmincenterApplication.class, args);
    }
}
